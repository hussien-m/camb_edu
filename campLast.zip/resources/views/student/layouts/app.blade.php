<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title') - Student Portal</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet">

    <style>
        * {
            font-family: 'Cairo', sans-serif;
        }
        body {
            background: #f8f9fa;
            min-height: 100vh;
        }
        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: 280px;
            background: linear-gradient(135deg, #1e3a8a 0%, #003366 100%);
            color: white;
            padding: 0;
            box-shadow: -4px 0 15px rgba(0,0,0,0.1);
            z-index: 1000;
            overflow-y: auto;
        }
        .sidebar-header {
            padding: 30px 20px;
            background: rgba(0,0,0,0.2);
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        .sidebar-header h4 {
            margin: 0;
            font-weight: 800;
            font-size: 1.5rem;
        }
        .sidebar-menu {
            padding: 20px 0;
        }
        .menu-item {
            display: flex;
            align-items: center;
            padding: 15px 25px;
            color: rgba(255,255,255,0.85);
            text-decoration: none;
            transition: all 0.3s;
            border-left: 4px solid transparent;
        }
        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            color: white;
            border-left-color: #ffcc00;
        }
        .menu-item.active {
            background: rgba(255,255,255,0.15);
            color: white;
            border-left-color: #ffcc00;
            font-weight: 700;
        }
        .menu-item i {
            margin-right: 15px;
            font-size: 1.2rem;
            width: 25px;
        }
        /* Main Content */
        .main-content {
            margin-left: 280px;
            padding: 30px;
        }
        /* Header */
        .top-header {
            background: white;
            padding: 20px 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .top-header h2 {
            margin: 0;
            font-weight: 800;
            color: #1e3a8a;
        }
        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .user-avatar {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: linear-gradient(135deg, #1e3a8a 0%, #003366 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 700;
            font-size: 1.2rem;
        }
        /* Cards */
        .dashboard-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 25px;
        }
        .card-title {
            font-size: 1.3rem;
            font-weight: 700;
            color: #1e3a8a;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        /* Status Badge */
        .status-badge {
            padding: 8px 20px;
            border-radius: 25px;
            font-weight: 700;
            font-size: 0.85rem;
        }
        .status-pending {
            background: #fef3c7;
            color: #92400e;
        }
        .status-active {
            background: #d1fae5;
            color: #065f46;
        }
        .status-inactive {
            background: #fee2e2;
            color: #991b1b;
        }
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s;
            }
            .sidebar.show {
                transform: translateX(0);
            }
            .main-content {
                margin-left: 0;
            }
        }
    </style>
    @stack('styles')
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <i class="fas fa-graduation-cap fa-3x mb-3"></i>
            <h4>{{ setting('site_name', 'Cambridge') }}</h4>
            <p class="mb-0 small">Student Portal</p>
        </div>

        <div class="sidebar-menu">
            <a href="{{ route('student.dashboard') }}" class="menu-item {{ request()->routeIs('student.dashboard') ? 'active' : '' }}">
                <i class="fas fa-home"></i>
                <span>Dashboard</span>
            </a>
            <a href="{{ route('student.courses.index') }}" class="menu-item {{ request()->routeIs('student.courses.*') || request()->routeIs('student.exams.*') ? 'active' : '' }}">
                <i class="fas fa-book"></i>
                <span>My Courses</span>
            </a>
            <a href="{{ route('student.certificates.index') }}" class="menu-item {{ request()->routeIs('student.certificates.*') ? 'active' : '' }}">
                <i class="fas fa-certificate"></i>
                <span>Certificates</span>
            </a>
            <a href="{{ route('student.profile') }}" class="menu-item {{ request()->routeIs('student.profile') ? 'active' : '' }}">
                <i class="fas fa-user"></i>
                <span>My Profile</span>
            </a>
            <a href="{{ route('home') }}" class="menu-item">
                <i class="fas fa-globe"></i>
                <span>Main Website</span>
            </a>
            <form method="POST" action="{{ route('student.logout') }}" class="m-0">
                @csrf
                <button type="submit" class="menu-item w-100 text-start border-0 bg-transparent">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </button>
            </form>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Header -->
        <div class="top-header">
            <h2>@yield('page-title')</h2>
            <div class="user-info">
                <div>
                    <div class="fw-bold">{{ auth()->guard('student')->user()->full_name }}</div>
                    <small class="text-muted">{{ auth()->guard('student')->user()->email }}</small>
                </div>
                @if(auth()->guard('student')->user()->profile_photo)
                    <img src="{{ asset('storage/' . auth()->guard('student')->user()->profile_photo) }}"
                         alt="Profile" class="user-avatar" style="width: 45px; height: 45px; object-fit: cover;">
                @else
                    <div class="user-avatar">
                        {{ strtoupper(substr(auth()->guard('student')->user()->first_name, 0, 1)) }}
                    </div>
                @endif
            </div>
        </div>

        @yield('content')
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    @stack('scripts')
</body>
</html>
