<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;
use App\Models\Certificate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CertificateController extends Controller
{
    public function index()
    {
        $student = Auth::guard('student')->user();
        $certificates = Certificate::with(['course', 'examAttempt.exam'])
            ->where('student_id', $student->id)
            ->latest('issue_date')
            ->get();

        return view('student.certificates.index', compact('certificates'));
    }

    public function show(Certificate $certificate)
    {
        $student = Auth::guard('student')->user();

        if ($certificate->student_id !== $student->id) {
            abort(403);
        }

        $certificate->load(['course', 'examAttempt.exam']);

        return view('student.certificates.show', compact('certificate'));
    }

    public function download(Certificate $certificate)
    {
        $student = Auth::guard('student')->user();

        if ($certificate->student_id !== $student->id) {
            abort(403);
        }

        $certificate->load(['course', 'examAttempt.exam', 'student']);

        return view('student.certificates.download', compact('certificate'));
    }
}
