<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Exam;
use App\Models\Question;
use App\Models\QuestionOption;
use Illuminate\Http\Request;

class QuestionController extends Controller
{
    public function create(Exam $exam)
    {
        return view('admin.questions.create', compact('exam'));
    }

    public function store(Request $request, Exam $exam)
    {
        $validated = $request->validate([
            'question_text' => 'required|string',
            'question_type' => 'required|in:multiple_choice,true_false',
            'points' => 'required|integer|min:1',
            'options' => 'required|array|min:2',
            'options.*.text' => 'required|string',
            'correct_option' => 'required|integer',
        ]);

        $question = $exam->questions()->create([
            'question_text' => $validated['question_text'],
            'question_type' => $validated['question_type'],
            'points' => $validated['points'],
            'order' => $exam->questions()->max('order') + 1,
        ]);

        foreach ($validated['options'] as $index => $option) {
            $question->options()->create([
                'option_text' => $option['text'],
                'is_correct' => ($index == $validated['correct_option']),
                'order' => $index + 1,
            ]);
        }

        return redirect()->route('admin.exams.show', $exam)
            ->with('success', 'Question added successfully.');
    }

    public function edit(Exam $exam, Question $question)
    {
        $question->load('options');
        return view('admin.questions.edit', compact('exam', 'question'));
    }

    public function update(Request $request, Exam $exam, Question $question)
    {
        $validated = $request->validate([
            'question_text' => 'required|string',
            'question_type' => 'required|in:multiple_choice,true_false',
            'points' => 'required|integer|min:1',
            'options' => 'required|array|min:2',
            'options.*.id' => 'nullable|exists:question_options,id',
            'options.*.text' => 'required|string',
            'correct_option' => 'required|integer',
        ]);

        $question->update([
            'question_text' => $validated['question_text'],
            'question_type' => $validated['question_type'],
            'points' => $validated['points'],
        ]);

        // Delete removed options
        $keepIds = collect($validated['options'])->pluck('id')->filter();
        $question->options()->whereNotIn('id', $keepIds)->delete();

        // Update or create options
        foreach ($validated['options'] as $index => $optionData) {
            $isCorrect = ($index == $validated['correct_option']);

            if (isset($optionData['id'])) {
                QuestionOption::find($optionData['id'])->update([
                    'option_text' => $optionData['text'],
                    'is_correct' => $isCorrect,
                    'order' => $index + 1,
                ]);
            } else {
                $question->options()->create([
                    'option_text' => $optionData['text'],
                    'is_correct' => $isCorrect,
                    'order' => $index + 1,
                ]);
            }
        }

        return redirect()->route('admin.exams.show', $exam)
            ->with('success', 'Question updated successfully.');
    }

    public function destroy(Exam $exam, Question $question)
    {
        $question->delete();
        return redirect()->route('admin.exams.show', $exam)
            ->with('success', 'Question deleted successfully.');
    }
}
