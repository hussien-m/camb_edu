<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ExamAttempt;
use App\Models\StudentAnswer;
use App\Models\Certificate;
use App\Models\Student;
use App\Models\Exam;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class ExamResultController extends Controller
{
    /**
     * Display a listing of exam results with filters
     */
    public function index(Request $request)
    {
        $query = ExamAttempt::with(['student', 'exam', 'certificate'])
            ->orderBy('created_at', 'desc');

        // Filter by student name
        if ($request->filled('student')) {
            $query->whereHas('student', function($q) use ($request) {
                $q->where('name', 'like', '%' . $request->student . '%');
            });
        }

        // Filter by exam
        if ($request->filled('exam_id')) {
            $query->where('exam_id', $request->exam_id);
        }

        // Filter by status (passed/failed)
        if ($request->filled('status')) {
            $query->where('passed', $request->status === 'passed' ? 1 : 0);
        }

        // Filter by date range
        if ($request->filled('date_from')) {
            $query->whereDate('created_at', '>=', $request->date_from);
        }
        if ($request->filled('date_to')) {
            $query->whereDate('created_at', '<=', $request->date_to);
        }

        $attempts = $query->paginate(20);
        $exams = Exam::all();

        return view('admin.exam-results.index', compact('attempts', 'exams'));
    }

    /**
     * Display detailed view of a specific exam attempt
     */
    public function show($id)
    {
        $attempt = ExamAttempt::with([
            'student',
            'exam.questions.options',
            'answers.question.options',
            'answers.selectedOption',
            'certificate'
        ])->findOrFail($id);

        // Calculate statistics
        $totalQuestions = $attempt->exam->questions->count();
        $correctAnswers = $attempt->answers->where('is_correct', true)->count();
        $wrongAnswers = $totalQuestions - $correctAnswers;

        return view('admin.exam-results.show', compact('attempt', 'totalQuestions', 'correctAnswers', 'wrongAnswers'));
    }

    /**
     * Show the form for editing exam results
     */
    public function edit($id)
    {
        $attempt = ExamAttempt::with(['student', 'exam', 'certificate'])->findOrFail($id);
        return view('admin.exam-results.edit', compact('attempt'));
    }

    /**
     * Update exam result manually
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'score' => 'required|numeric|min:0',
            'percentage' => 'required|numeric|min:0|max:100',
            'passed' => 'required|boolean',
            'admin_notes' => 'nullable|string',
        ]);

        DB::beginTransaction();
        try {
            $attempt = ExamAttempt::findOrFail($id);

            $attempt->update([
                'score' => $request->score,
                'percentage' => $request->percentage,
                'passed' => $request->passed,
                'admin_notes' => $request->admin_notes,
            ]);

            // Handle certificate generation/deletion
            if ($request->passed) {
                if (!$attempt->certificate) {
                    $this->generateCertificate($attempt);
                }
            } else {
                if ($attempt->certificate) {
                    $attempt->certificate->delete();
                }
            }

            DB::commit();
            return redirect()->route('admin.exam-results.index')
                ->with('success', 'Result updated successfully');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Error updating result: ' . $e->getMessage());
        }
    }

    /**
     * Recalculate score based on saved answers
     */
    public function recalculate($id)
    {
        DB::beginTransaction();
        try {
            $attempt = ExamAttempt::with(['answers', 'exam'])->findOrFail($id);

            $correctCount = 0;
            $totalQuestions = $attempt->exam->questions()->count();

            // Recalculate each answer
            foreach ($attempt->answers as $answer) {
                $question = $answer->question;
                $correctOption = $question->options()->where('is_correct', true)->first();

                if ($correctOption && $answer->selected_option_id == $correctOption->id) {
                    $answer->is_correct = true;
                    $answer->points_earned = $question->points ?? 1;
                    $correctCount++;
                } else {
                    $answer->is_correct = false;
                    $answer->points_earned = 0;
                }
                $answer->save();
            }

            // Calculate total score and percentage
            $totalMarks = $attempt->exam->total_marks;
            $earnedMarks = $attempt->answers->sum('points_earned');
            $percentage = $totalMarks > 0 ? ($earnedMarks / $totalMarks) * 100 : 0;
            $passed = $percentage >= $attempt->exam->passing_percentage;

            // Update attempt
            $attempt->update([
                'score' => $earnedMarks,
                'percentage' => round($percentage, 2),
                'passed' => $passed,
            ]);

            // Handle certificate
            if ($passed && !$attempt->certificate) {
                $this->generateCertificate($attempt);
            } elseif (!$passed && $attempt->certificate) {
                $attempt->certificate->delete();
            }

            DB::commit();
            return redirect()->back()->with('success', 'Score recalculated successfully');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Error recalculating score: ' . $e->getMessage());
        }
    }

    /**
     * Delete exam attempt with all related data
     */
    public function destroy($id)
    {
        DB::beginTransaction();
        try {
            $attempt = ExamAttempt::with(['answers', 'certificate'])->findOrFail($id);

            // Delete certificate if exists
            if ($attempt->certificate) {
                // Delete certificate file if exists
                if ($attempt->certificate->certificate_file) {
                    Storage::disk('public')->delete($attempt->certificate->certificate_file);
                }
                $attempt->certificate->delete();
            }

            // Delete all answers
            $attempt->answers()->delete();

            // Delete attempt
            $attempt->delete();

            DB::commit();
            return redirect()->route('admin.exam-results.index')
                ->with('success', 'Attempt deleted successfully');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Error deleting attempt: ' . $e->getMessage());
        }
    }

    /**
     * Generate certificate for passed attempt
     */
    private function generateCertificate($attempt)
    {
        Certificate::create([
            'student_id' => $attempt->student_id,
            'exam_id' => $attempt->exam_id,
            'enrollment_id' => $attempt->enrollment_id,
            'exam_attempt_id' => $attempt->id,
            'certificate_number' => $this->generateCertificateNumber(),
            'issue_date' => now(),
            'score' => $attempt->score,
            'percentage' => $attempt->percentage,
        ]);
    }

    /**
     * Generate unique certificate number
     */
    private function generateCertificateNumber()
    {
        return 'CERT-' . strtoupper(uniqid()) . '-' . date('Y');
    }
}
