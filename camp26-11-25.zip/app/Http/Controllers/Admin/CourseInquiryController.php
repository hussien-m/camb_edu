<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CourseInquiry;
use Illuminate\Http\Request;

class CourseInquiryController extends Controller
{
    public function index()
    {
        $inquiries = CourseInquiry::with('course')
            ->latest()
            ->paginate(20);

        return view('admin.inquiries.index', compact('inquiries'));
    }

    public function show(CourseInquiry $inquiry)
    {
        $inquiry->load('course');
        return view('admin.inquiries.show', compact('inquiry'));
    }

    public function updateStatus(Request $request, CourseInquiry $inquiry)
    {
        $request->validate([
            'status' => 'required|in:new,contacted,closed'
        ]);

        $inquiry->update(['status' => $request->status]);

        return redirect()->back()->with('success', 'Inquiry status updated successfully.');
    }

    public function destroy(CourseInquiry $inquiry)
    {
        $inquiry->delete();
        return redirect()->route('admin.inquiries.index')
            ->with('success', 'Inquiry deleted successfully.');
    }
}
