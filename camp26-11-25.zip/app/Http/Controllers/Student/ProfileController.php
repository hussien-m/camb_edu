<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class ProfileController extends Controller
{
    public function edit()
    {
        $student = auth()->guard('student')->user();
        return view('student.profile', compact('student'));
    }

    public function update(Request $request)
    {
        $student = auth()->guard('student')->user();

        $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => ['required', 'email', Rule::unique('students')->ignore($student->id)],
            'phone' => 'nullable|string|max:20',
            'date_of_birth' => 'nullable|date|before:today',
            'country' => 'nullable|string|max:100',
            'profile_photo' => 'nullable|image|mimes:jpeg,png,jpg|max:2048',
            'current_password' => 'nullable|required_with:new_password',
            'new_password' => 'nullable|min:8|confirmed',
        ]);

        // تحديث البيانات الأساسية
        $student->first_name = $request->first_name;
        $student->last_name = $request->last_name;
        $student->email = $request->email;
        $student->phone = $request->phone;
        $student->date_of_birth = $request->date_of_birth;
        $student->country = $request->country;

        // رفع الصورة
        if ($request->hasFile('profile_photo')) {
            // حذف الصورة القديمة
            if ($student->profile_photo) {
                Storage::disk('public')->delete($student->profile_photo);
            }

            $path = $request->file('profile_photo')->store('students', 'public');
            $student->profile_photo = $path;
        }

        // تحديث كلمة المرور
        if ($request->filled('new_password')) {
            if (!Hash::check($request->current_password, $student->password)) {
                return back()->withErrors(['current_password' => 'Current password is incorrect.'])->withInput();
            }
            $student->password = Hash::make($request->new_password);
        }

        $student->save();

        return back()->with('success', 'Profile updated successfully!');
    }
}
