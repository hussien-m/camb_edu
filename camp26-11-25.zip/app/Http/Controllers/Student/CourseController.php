<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\Enrollment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CourseController extends Controller
{
    public function index()
    {
        $student = Auth::guard('student')->user();

        $enrolledCourseIds = $student->enrollments()->pluck('course_id');

        $courses = Course::with([
            'exams' => function($query) use ($student) {
                $query->with(['attempts' => function($q) use ($student) {
                    $q->where('student_id', $student->id)
                      ->orderBy('created_at', 'desc');
                }]);
            },
            'enrollments' => function($query) use ($student) {
                $query->where('student_id', $student->id);
            },
            'category',
            'level'
        ])
        ->whereIn('id', $enrolledCourseIds)
        ->get();

        return view('student.courses.index', compact('courses'));
    }

    public function enroll(Course $course)
    {
        $student = Auth::guard('student')->user();

        // Check if already enrolled
        $existing = Enrollment::where('student_id', $student->id)
            ->where('course_id', $course->id)
            ->first();

        if ($existing) {
            return back()->with('info', 'You are already enrolled in this course.');
        }

        Enrollment::create([
            'student_id' => $student->id,
            'course_id' => $course->id,
            'status' => 'active',
            'enrolled_at' => now(),
        ]);

        return redirect()->route('student.courses.index')
            ->with('success', 'Successfully enrolled in ' . $course->title);
    }
}
