<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;
use App\Models\Exam;
use App\Models\ExamAttempt;
use App\Models\Enrollment;
use App\Models\StudentAnswer;
use App\Models\Certificate;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ExamController extends Controller
{
    public function show(Exam $exam)
    {
        $student = Auth::guard('student')->user();

        // Check enrollment
        $enrollment = Enrollment::where('student_id', $student->id)
            ->where('course_id', $exam->course_id)
            ->where('status', 'active')
            ->first();

        if (!$enrollment) {
            return redirect()->route('student.courses.index')
                ->with('error', 'You must be enrolled in this course to take the exam.');
        }

        // Check attempts
        $attempts = ExamAttempt::where('student_id', $student->id)
            ->where('exam_id', $exam->id)
            ->count();

        if ($attempts >= $exam->max_attempts) {
            return redirect()->route('student.courses.index')
                ->with('error', 'You have reached the maximum number of attempts for this exam.');
        }

        // Check if there's an in-progress attempt
        $currentAttempt = ExamAttempt::where('student_id', $student->id)
            ->where('exam_id', $exam->id)
            ->where('status', 'in_progress')
            ->first();

        if ($currentAttempt) {
            return redirect()->route('student.exams.take', $currentAttempt);
        }

        // Get previous attempts for display
        $previousAttempts = ExamAttempt::where('student_id', $student->id)
            ->where('exam_id', $exam->id)
            ->where('status', 'completed')
            ->orderBy('created_at', 'desc')
            ->get();

        $attemptCount = $attempts;

        return view('student.exams.show', compact('exam', 'enrollment', 'attemptCount', 'previousAttempts'));
    }

    public function start(Exam $exam)
    {
        $student = Auth::guard('student')->user();

        $enrollment = Enrollment::where('student_id', $student->id)
            ->where('course_id', $exam->course_id)
            ->where('status', 'active')
            ->firstOrFail();

        $attemptNumber = ExamAttempt::where('student_id', $student->id)
            ->where('exam_id', $exam->id)
            ->count() + 1;

        $attempt = ExamAttempt::create([
            'student_id' => $student->id,
            'exam_id' => $exam->id,
            'enrollment_id' => $enrollment->id,
            'start_time' => now(),
            'attempt_number' => $attemptNumber,
            'status' => 'in_progress',
        ]);

        return redirect()->route('student.exams.take', $attempt);
    }

    public function take(ExamAttempt $attempt)
    {
        $student = Auth::guard('student')->user();

        if ($attempt->student_id !== $student->id) {
            abort(403);
        }

        if ($attempt->status !== 'in_progress') {
            return redirect()->route('student.exams.result', $attempt);
        }

        // Check if exam expired - use copy() to avoid modifying original
        $endTime = $attempt->start_time->copy()->addMinutes($attempt->exam->duration);
        $expired = now()->gt($endTime);

        if ($expired) {
            $this->finishAttempt($attempt, true);
            return redirect()->route('student.exams.result', $attempt)
                ->with('warning', 'Exam time has expired.');
        }

        $exam = $attempt->exam->load('questions.options');
        $questions = $exam->questions;

        // Get answered questions with their selected options
        $answeredQuestions = [];
        foreach ($attempt->answers as $answer) {
            $answeredQuestions[$answer->question_id] = $answer->selected_option_id;
        }

        return view('student.exams.take', compact('attempt', 'exam', 'questions', 'answeredQuestions', 'expired'));
    }

    public function submitAnswer(Request $request, ExamAttempt $attempt)
    {
        $validated = $request->validate([
            'question_id' => 'required|exists:questions,id',
            'option_id' => 'required|exists:question_options,id',
        ]);

        $question = $attempt->exam->questions()->findOrFail($validated['question_id']);
        $option = $question->options()->findOrFail($validated['option_id']);

        StudentAnswer::updateOrCreate(
            [
                'attempt_id' => $attempt->id,
                'question_id' => $question->id,
            ],
            [
                'selected_option_id' => $option->id,
                'is_correct' => $option->is_correct,
                'points_earned' => $option->is_correct ? $question->points : 0,
            ]
        );

        return response()->json(['success' => true]);
    }

    public function submit(ExamAttempt $attempt)
    {
        $this->finishAttempt($attempt);

        return redirect()->route('student.exams.result', $attempt)
            ->with('success', 'Exam submitted successfully.');
    }

    public function result(ExamAttempt $attempt)
    {
        $student = Auth::guard('student')->user();

        if ($attempt->student_id !== $student->id) {
            abort(403);
        }

        if ($attempt->status === 'in_progress') {
            return redirect()->route('student.exams.take', $attempt);
        }

        $attempt->load(['exam.questions.options', 'answers.question', 'answers.selectedOption', 'certificate']);

        $correctAnswers = $attempt->answers->where('is_correct', true)->count();
        $totalQuestions = $attempt->exam->questions->count();
        $remainingAttempts = $attempt->exam->max_attempts - $attempt->attempt_number;

        return view('student.exams.result', compact('attempt', 'correctAnswers', 'totalQuestions', 'remainingAttempts'));
    }

    private function finishAttempt(ExamAttempt $attempt, $expired = false)
    {
        $totalScore = $attempt->answers()->sum('points_earned');
        $totalMarks = $attempt->exam->total_marks;
        $percentage = ($totalScore / $totalMarks) * 100;
        $passed = $percentage >= $attempt->exam->passing_score;

        $attempt->update([
            'end_time' => now(),
            'score' => $totalScore,
            'percentage' => $percentage,
            'passed' => $passed,
            'status' => $expired ? 'expired' : 'completed',
        ]);

        // Generate certificate if passed
        if ($passed) {
            $this->generateCertificate($attempt);
        }
    }

    private function generateCertificate(ExamAttempt $attempt)
    {
        Certificate::create([
            'student_id' => $attempt->student_id,
            'course_id' => $attempt->exam->course_id,
            'exam_attempt_id' => $attempt->id,
            'certificate_number' => Certificate::generateCertificateNumber(),
            'issue_date' => now(),
        ]);

        // Mark enrollment as completed
        $attempt->enrollment->update([
            'status' => 'completed',
            'completed_at' => now(),
            'progress' => 100,
        ]);
    }
}
